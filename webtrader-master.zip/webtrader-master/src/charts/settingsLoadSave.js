/* created by amin, on July 07, 2016 */

define(['websockets/binary_websockets', 'windows/windows', 'common/rivetsExtra'], function(liveapi, windows, rv) {
    require(['text!charts/settingsLoadSave.html']);
    require(['css!charts/settingsLoadSave.css']);
    var win = null;
    var win_view = null;

  });
